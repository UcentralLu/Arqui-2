export const environment = {
  production: false,
  base_url: 'http://localhost:4000/api/v1',
};
