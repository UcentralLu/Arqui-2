export class PaisModel {
  constructor(
    public nombre: string,
    public name: string,
    public nom: string,
    public iso2: string,
    public iso3: string,
    public phone_code: string
  ) {}
}
