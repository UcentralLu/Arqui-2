import { RolDirective } from './rol.directive';

describe('RolDirective', () => {
  it('should create an instance', () => {
    const directive = new RolDirective();
    expect(directive).toBeTruthy();
  });
});
