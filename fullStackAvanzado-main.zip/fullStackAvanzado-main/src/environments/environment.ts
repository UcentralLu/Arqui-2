export const environment = {
  production: true,
  base_url: 'https://backendexpress-dfqo.onrender.com/api/v1',
};
